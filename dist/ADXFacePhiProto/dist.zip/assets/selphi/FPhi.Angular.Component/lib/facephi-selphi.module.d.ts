export declare class FacePhiSelphiModule {
}
