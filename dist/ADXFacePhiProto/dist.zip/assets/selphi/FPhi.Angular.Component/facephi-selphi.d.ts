/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { FPhiSelphiWidgetService as ɵa } from './lib/services/fphi-selphi-widget.service';
