export declare class FacePhiSelphIdModule {
}
