importScripts('DocumentExtractor.js', 'bindings.js', 'worker.js');
